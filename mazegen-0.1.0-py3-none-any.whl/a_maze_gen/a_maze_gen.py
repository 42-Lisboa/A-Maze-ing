import random

NORTH = 1 << 0  # Binary: 0001 (Decimal: 1)
EAST = 1 << 1  # Binary: 0010 (Decimal: 2)
SOUTH = 1 << 2  # Binary: 0100 (Decimal: 4)
WEST = 1 << 3  # Binary: 1000 (Decimal: 8)


# =============================================================================
#                               🧱 MazeGenerator 🧱
# -----------------------------------------------------------------------------

class MazeGenerator:
    """Generates a maze using Depth-First Search and specific constraints.

    Attributes:
        width (int): The width of the maze grid.
        height (int): The height of the maze grid.
        maze_entry (tuple[int, int]): The (x, y) entry coordinates.
        maze_exit (tuple[int, int]): The (x, y) exit coordinates.
        output_file (str): The filename for exporting the maze data.
        perfect (bool): True - perfect maze (one path), False - playable board.
        seed (int | None): The random seed for reproducible maze generation.
        grid (list[list[int]]): The 2D matrix representing the maze cells.
    """
    def __init__(
            self,
            width: int, height: int, maze_entry: tuple[int, int],
            maze_exit: tuple[int, int], output_file: str,
            perfect: bool = False, seed: int | None = None):
        self.width = width
        self.height = height
        self.maze_entry = maze_entry
        self.maze_exit = maze_exit
        self.output_file = output_file
        self.perfect = perfect
        self.seed = seed
        self.int_seed = random.Random(seed)
        self.grid: list[list[int]] = []
        self._validate()

    # ================ 0. Simple validation to reusable module ================

    def _validate(self) -> None:
        """Checks the maze rules that the generator depends on.

        Raises:
            ValueError: If size, entry or exit are invalid.
        """
        if not (2 <= self.width <= 50 and 2 <= self.height <= 50):
            raise ValueError("Size must be 2-50 (width) and 2-50 (height)")

        blocked = self.get_42_coords()
        for name, (x, y) in (("entry", self.maze_entry),
                             ("exit", self.maze_exit)):
            if not (0 <= x < self.width and 0 <= y < self.height):
                raise ValueError(f"The {name} is outside the grid")
            if (x, y) in blocked:
                raise ValueError(f"The {name} is on a '42' cell")

        if self.maze_entry == self.maze_exit:
            raise ValueError("Entry and exit must be different")

    # ================= 1. Create Maze with all cells closed =================

    def create_closed_cells(self) -> list[list[int]]:
        """Initializes the maze grid with all walls closed.

        Each cell is initialized with the value 15 (binary 1111), meaning
        all four walls (North, East, South, West) are solid.

        Returns:
            list[list[int]]: The generated 2D grid matrix.
        """
        self.grid = []
        for _ in range(self.height):
            current_row: list[int] = []
            self.grid.append(current_row)
            for _ in range(self.width):
                current_row.append(15)
        return self.grid

    # ============== 2. Get 42 coordinates blocked cells pattern ==============

    def get_42_coords(self) -> set[tuple[int, int]]:
        """Calculates the coordinates of the centered '42' blocked pattern.

        Returns:
            set[tuple[int, int]]: A set of (x, y) coordinates from the '42'.
        """
        pattern_width, pattern_height = 7, 5

        # Too small for the "42" plus a 1-cell border: omit the pattern
        if self.width < 9 or self.height < 7:
            return set()

        start_x_pattern = (self.width - pattern_width) // 2
        start_y_pattern = (self.height - pattern_height) // 2

        # Matriz local do "42" (relativa ao bloco 7x5):
        # 1 = célula fechada, 0 = espaço
        pattern_grid = [
            [1, 0, 1,  0,  1, 1, 1],
            [1, 0, 1,  0,  0, 0, 1],
            [1, 1, 1,  0,  1, 1, 1],
            [0, 0, 1,  0,  1, 0, 0],
            [0, 0, 1,  0,  1, 1, 1],
        ]
        coords_42 = set()
        for dy, row in enumerate(pattern_grid):
            # ie: where dy = 0, row = [1, 0, 1,  0,  1, 1, 1]
            for dx, cell in enumerate(row):
                # ie: where dx = 0, cell = 1
                if cell == 1:
                    coords_42.add((start_x_pattern + dx, start_y_pattern + dy))

        return coords_42

    # ================ 3. Method to validate cell coordinates ================

    def is_neighbor_coords_valid(self,
                                 neighbor_cell_coords: tuple[int, int],
                                 visited_cells: set[tuple[int, int]]) -> bool:
        """Checks if a neighbor cell is within the grid limits and unvisited.

        Args:
            neighbor_cell_coords (tuple[int, int]): The coordinates to check.
            visited_cells (set[tuple[int, int]]): Set of already visited cells.

        Returns:
            bool: True- cell is valid and hasn't been visited, False otherwise.
        """
        x, y = neighbor_cell_coords
        if neighbor_cell_coords in visited_cells:
            return False
        if x >= 0 and y >= 0 and x < self.width and y < self.height:
            return True
        else:
            return False

    # ========= 4. Dig the perfect Maze using DFS-Depth First Search =========

    def maze_digger(self, start: tuple[int, int]) -> None:
        """Carves the maze paths using an iterative Depth-First Search (DFS)
        algorithm.

        Args:
            start (tuple[int, int]): The (x, y) starting coordinates for the
            excavation.
        """

        # 🔸 Create a compass ruler when moving each direction
        # (changer_x, changer_y, delete_wall_here, delete_wall_there)

        compass: list[tuple[int, int, int, int]] = [
            (0, -1, NORTH, SOUTH),  # N rule
            (+1, 0, EAST, WEST),    # E rule
            (0, +1, SOUTH, NORTH),  # S rule
            (-1, 0, WEST, EAST)     # W rule
        ]

        # 🔸 Save 42 blocked pattern on visited cells and begin DFS maze dig

        visited_cells = self.get_42_coords()
        stack = [start]

        while stack:
            x, y = stack[-1]  # we unpack last cell from stack
            visited_cells.add((x, y))
            self.int_seed.shuffle(compass)
            for changer_x, changer_y, d_wall_here, d_wall_there in compass:
                n_x = x + changer_x  # n - neighbor
                n_y = y + changer_y  # n - neighbor
                neighbor_cell = (n_x, n_y)
                if self.is_neighbor_coords_valid(neighbor_cell, visited_cells):
                    self.grid[y][x] = self.grid[y][x] & ~ d_wall_here
                    self.grid[n_y][n_x] = self.grid[n_y][n_x] & ~ d_wall_there
                    stack.append((n_x, n_y))
                    break  # to stop compass for loop
            else:
                stack.pop()  # to remove already "finished" cell and trace back

    # ===== 5. Function to check if there is big pools on Imperfect Mazes =====

    def has_3x3_pool(self) -> bool:
        """Checks if the maze contains any 3x3 open areas.

        A pool is defined as a 3x3 block of cells with no internal walls
        dividing them.

        Returns:
            bool: True if at least one 3x3 pool is detected, False otherwise.
        """
        for y in range(self.height - 2):
            for x in range(self.width - 2):
                has_wall = False
                for dy in range(3):  # y movement (Δy)
                    grid_y = y + dy
                    for dx in range(3):  # x movement (Δx)
                        grid_x = x + dx
                        if self.grid[grid_y][grid_x] & EAST == 2 and dx < 2:
                            has_wall = True
                            break
                        if self.grid[grid_y][grid_x] & SOUTH == 4 and dy < 2:
                            has_wall = True
                            break
                    if has_wall:
                        break
                if not has_wall:
                    return True
        return False

    # =================== 6. Break extra walls on dead-ends ===================

    def break_extra_walls_de(self) -> None:
        """Breaks extra walls in dead-end cells to create an imperfect,
        playable maze.

        Ensures that removing walls does not create illegal 3x3 open pools
        or break into the protected '42' pattern blocks.
        """

        # 🔸 Create a compass ruler when moving each direction
        # (changer_x, changer_y, delete_wall_here, delete_wall_there)

        compass: list[tuple[int, int, int, int]] = [
            (0, -1, NORTH, SOUTH),  # N rule
            (+1, 0, EAST, WEST),    # E rule
            (0, +1, SOUTH, NORTH),  # S rule
            (-1, 0, WEST, EAST)     # W rule
        ]

        # 🔸 We check which walls to remove only from dead-end cells (3 walls)

        blocked_cells = self.get_42_coords()

        for y, row in enumerate(self.grid):
            for x, cell in enumerate(row):
                walls_2_remove: list[tuple[int, int, int, int]] = []

                if cell.bit_count() != 3:
                    continue
                if cell & NORTH == 1:
                    walls_2_remove.append(compass[0])
                if cell & EAST == 2:
                    walls_2_remove.append(compass[1])
                if cell & SOUTH == 4:
                    walls_2_remove.append(compass[2])
                if cell & WEST == 8:
                    walls_2_remove.append(compass[3])

                # 🔸 Now as soon one wall is validated we remove it

                self.int_seed.shuffle(walls_2_remove)
                for changer_x, changer_y, \
                        d_wall_here, d_wall_there in walls_2_remove:
                    n_y = y + changer_y  # n - neighbor
                    n_x = x + changer_x  # n - neighbor
                    neighbor = (n_x, n_y)
                    if self.is_neighbor_coords_valid(neighbor, blocked_cells):
                        self.grid[y][x] = \
                            self.grid[y][x] & ~ d_wall_here
                        self.grid[n_y][n_x] = \
                            self.grid[n_y][n_x] & ~ d_wall_there

                        # 🔸 If the wall removed create a big pool we rebuilt it

                        if self.has_3x3_pool():
                            self.grid[y][x] = \
                                self.grid[y][x] | d_wall_here
                            self.grid[n_y][n_x] = \
                                self.grid[n_y][n_x] | d_wall_there
                            continue
                        else:
                            break

    # ================= 7. Build the whole maze in one call =================

    def generate(self) -> list[list[int]]:
        """Builds the complete maze respecting the 'perfect' flag.

        Closes all cells, digs the maze with DFS and, if 'perfect' is
        False, breaks the dead-ends to create loops.

        Returns:
            list[list[int]]: The generated 2D grid matrix.
        """
        self.create_closed_cells()
        self.maze_digger(start=self.maze_entry)
        if not self.perfect:
            self.break_extra_walls_de()
        return self.grid

    # ============ 8. Method to solve the generated maze using BFS ============

    def solve(self) -> str | None:
        """Finds the shortest path from entry to exit using BFS: Breadth-First
        Search.

        Returns:
            str | None: The solution path string (e.g., 'EESW'), or None if no
            path.
        """
        if self.grid:

            # 🔸 Save 42 blocked cells on visited and begin BFS maze search
            visited_cells = self.get_42_coords()
            queue = [(self.maze_entry, "")]  # coords + path trace

            while queue:

                # 🔸 Pop a cell from the front of queue and check if it's exit
                cell = queue.pop(0)
                if cell[0] == self.maze_exit:
                    return cell[1]  # returns the path trace

                # 🔸 Unpack cell so we can calculate neighbors coords
                x, y = cell[0]
                path_trace = cell[1]

                # 🔸 For each open direction we add neighbors coords + trace
                if (self.grid[y][x] & NORTH) == 0:
                    n_cell = (x, y - 1)
                    if n_cell not in visited_cells:
                        visited_cells.add(n_cell)
                        queue.append((n_cell, path_trace + "N"))

                if (self.grid[y][x] & EAST) == 0:
                    n_cell = (x + 1, y)
                    if n_cell not in visited_cells:
                        visited_cells.add(n_cell)
                        queue.append((n_cell, path_trace + "E"))

                if (self.grid[y][x] & SOUTH) == 0:
                    n_cell = (x, y + 1)
                    if n_cell not in visited_cells:
                        visited_cells.add(n_cell)
                        queue.append((n_cell, path_trace + "S"))

                if (self.grid[y][x] & WEST) == 0:
                    n_cell = (x - 1, y)
                    if n_cell not in visited_cells:
                        visited_cells.add(n_cell)
                        queue.append((n_cell, path_trace + "W"))

        return None


# ============================== Program Test ================================

if __name__ == "__main__":
    print("=== Starting MazeGenerator Test ===\n")

    # 1. Mocking the data that would normally come from your MazeParser
    test_width = 20
    test_height = 15
    test_entry = (0, 14)
    test_exit = (19, 0)

    maze = MazeGenerator(
        width=test_width,
        height=test_height,
        maze_entry=test_entry,
        maze_exit=test_exit,
        output_file="test_maze.txt",
        perfect=False,  # Set to False to test the Pac-Man mode
        seed=13
    )

    # 2. Executing the whole generation pipeline in one call
    print("🧱 Generating maze (closed grid + DFS + dead-ends)...")
    maze.generate()
    print(f"Solution: {maze.solve()}")
    print(f"Grid created: {len(maze.grid)} rows by "
          f"{len(maze.grid[0])} columns.\n")

    if maze.perfect:
        print("💎 PERFECT=True detected. Maze has a single path.\n")
    else:
        print("🔨 PERFECT=False detected. Extra walls were broken "
              "to remove dead-ends without creating pools!\n")

    print("✅ Maze generation logic executed successfully!")

    # 3. Printing a sample of the final grid memory to confirm integer values
    print(f"\nSample data from Row 0: {maze.grid[0]}")
